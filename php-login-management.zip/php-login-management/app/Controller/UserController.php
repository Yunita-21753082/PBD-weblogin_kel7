<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Controller;

class UserController
{
    public function register(){
        View::render('User/register', [
            'title' => 'Register new User'
        ]);

    }

    public function postRegister(){

    }
}