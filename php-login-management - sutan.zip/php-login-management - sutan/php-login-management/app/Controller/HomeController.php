<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Controller;

use ProgrammerZamanNow\Belajar\PHP\MVC\App\View;
use ProgrammerZamanNow\Belajar\PHP\MVC\Config\Database;
use ProgrammerZamanNow\Belajar\PHP\MVC\Service\SessionService;

class HomeController
{

    private SessionService $sessionService;

    public function __construct()
    {
        $connecion = Database::getConnection();
        $sessionRepository = new sessionRepository($connecion);
        $userRepository =  new userRepository($connecion);
        $this->sessionService = new SessionService($sessionRepository, $userRepository);
    }


    function index(){
        $user = $this->sessionService->current();
        if ($user == null){
            View::render('Home/index', [
                "title" => "PHP Login Management"
            ]);
        }else{
            View::render('Home/dashboard', [
                "title" => "dashboard",
                "user" => [
                    "name" => $user->name
                ]
            ]);
        }

    }
}