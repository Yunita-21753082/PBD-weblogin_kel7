<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

class UserRegisterResponse
{

}