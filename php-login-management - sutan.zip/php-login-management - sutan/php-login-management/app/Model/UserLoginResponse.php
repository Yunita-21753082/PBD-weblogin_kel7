<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Model;

class UserLoginResponse
{
    public User $user;

}