<?php

namespace ProgrammerZamanNow\Belajar\PHP\MVC\Domain;

class Session
{
    public string $id;
    public string $userId;


}